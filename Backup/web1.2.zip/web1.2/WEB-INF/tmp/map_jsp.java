package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import com.mapinfo.mapj.*;

public class map_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GB2312");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      
String flag=request.getParameter("flag");
if(flag!=null&&flag.equals("true")){
    MapJ mymap=(MapJ)session.getAttribute("mapj");
	Layer tlayer=null;
    if(mymap!=null){
		for (int i=0;i<mymap.getLayers().size();i++){
			tlayer=mymap.getLayers().elementAt(i);
			String param1="isview"+i;
			String param2="isselect"+i;
			String param3="islabel"+i;
			String isview=request.getParameter(param1);
			String isselect=request.getParameter(param2);
			String islabel=request.getParameter(param3);
			if(isview!=null&&isview.equals("true"))
			    tlayer.setVisible(true);
			else
			    tlayer.setVisible(false);
			if(isselect!=null&&isselect.equals("true"))
			    tlayer.setSelectable(true);
			else
			    tlayer.setSelectable(false);
			if(islabel!=null&&islabel.equals("true"))
			    tlayer.setAutoLabel(true);
			else
			    tlayer.setAutoLabel(false);
		}
    }
}

      out.write("\r\n<html>\r\n<head>\r\n<title>让我好好稀罕稀罕你</title>\r\n<style type=\"text/css\">\r\n<!--\r\n.css1 {  font-size: 12pt; color: #FFFFFF}\r\n-->\r\n</style>\r\n<script language=\"JavaScript\" src=\"scripts/mapevent.js\">\r\n</script>\r\n<script language=\"JavaScript\" src=\"scripts/mapmove.js\">\r\n</script>\r\n<script language=\"JavaScript\" src=\"scripts/maprquest.js\">\r\n</script>\r\n<script language=\"JavaScript\" type=\"text/javascript\" src=\"scripts/wz_jsgraphics.js\">\r\n</script>\r\n<script language=\"JavaScript\" >\r\nfunction resetimg(){\r\n\tif(state==\"big\"){\t\t\r\n\t\tdocument.all.bigimg.src=\"images/index-map_03.jpg\"\r\n\t}\r\n\telse if(state==\"small\"){\r\n\t\tdocument.all.smallimg.src=\"images/index-map_05.jpg\"\r\n\t}\r\n\telse if(state==\"pan\"){\r\n\t\tdocument.all.panimg.src=\"images/index-map_06.jpg\"\r\n\t}\r\n\tdocument.all.mxx.style.display=\"none\";\r\n\tdocument.all.mapCanvas.style.display=\"none\";\r\n\t\r\n}\r\n</script>\r\n</head>\r\n<body bgcolor=\"#DFFFDF\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"  >\r\n\r\n<img src=\"images/map_03.jpg\" style=\"position:absolute;left:9px;top:9px;width:482px\" border=\"0\" > \r\n");
      out.write("<img name=\"downloadimg\" src=\"images/shalou.gif\" style=\"position:absolute;left:220px;top:180px;z-index:2;\" >\r\n<div id=\"mapCanvas\" style=\"position:absolute;left:9px;top:24px;height:362px;width:482px;display:none;z-index: 20; \" > \r\n</div> \r\n<div id=\"mxx\" style=\"position:absolute;left:9px;top:24px;height:362px;width:482px; display:none;z-index:18;background-image:url(images/opp.gif)\" > \r\n</div>\r\n<div id=\"mapframe\" style=\"position:absolute;left:9px;top:24px;height:362px;width:482px;overflow:hidden;background-color:#99FFFF;layer-background-color:#99FFFF;border:1px #3399; \">\r\n\t<img id=\"imgmap\" GALLERYIMG=\"false\" style=\"position:relative;left:0px;top:0px;height:360px;width:480px;cursor:default;  \"> \r\n</div> \r\n<!--div缩略图边框，img为缩略图-->\r\n<div id=\"mapboundframe\" style=\"position:absolute;left:521px;top:240px;height:182px;width:242px;overflow:hidden;background-color:#99FFFF;layer-background-color:#99FFFF;border:1px #339933 solid;display:none\"> \r\n\t<img id=\"boundmap\" GALLERYIMG=\"false\" style=\"position:relative;left:0px;top:0px;visibility:hidden;height:180px;width:240px;\" onClick=\"mapsmallpaner()\"> \r\n");
      out.write("</div>\r\n<IFRAME id=\"center\" style=\"display:none\"></IFRAME>\r\n<IFRAME id=\"zoom\" style=\"display:none\"></IFRAME>\r\n<table id=\"seltable\" style=\"position:absolute;border:1px solid Red;width:0px;height:0px;display:none; \">\r\n\t<tr><td></td></tr>\r\n</table>\r\n<img name=\"selimg\" style=\"position:absolute;border:1px solid Red;width:1px;height:1px;display:none;\">\r\n<!--以下table显示的是地图操作按钮-->\r\n<table width=\"31%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"position:absolute;left:521px;top:10px;; width: 178px; height: 182px\" >\r\n  <tr valign=\"middle\" align=\"left\"> \r\n    <td><img name=\"bigimg\" src=\"images/index-map_03.jpg\" width=\"159\" height=\"28\" onClick=\"mapbig()\" style=\"cursor:hand\" alt=\"区域放大地图\"></td>\r\n  </tr>\r\n  <tr> \r\n    <td><img name=\"smallimg\" src=\"images/index-map_05.jpg\" width=\"159\" onClick=\"mapsmall()\" style=\"cursor:hand\" alt=\"点击缩小地图\"></td>\r\n  </tr>\r\n  <tr> \r\n    <td><img name=\"panimg\" src=\"images/index-map_06.jpg\" width=\"159\" height=\"28\" onClick=\"mappan()\" style=\"cursor:hand\" alt=\"浏览地图\"></td>\r\n  </tr>\r\n  <tr> \r\n    <td><img name=\"resetimg\" src=\"images/index-map_07.jpg\" width=\"159\" height=\"29\" onClick=\"mapreset()\" style=\"cursor:hand\" alt=\"恢复地图初始状态\"></td>\r\n");
      out.write("  </tr>\r\n  <tr> \r\n    <td><img src=\"images/index-map_08.jpg\" width=\"159\" height=\"29\" onClick=\"mapbound()\" style=\"cursor:hand\" alt=\"缩略图\"></td>\r\n  </tr>\r\n  <tr>\r\n    <td><img src=\"images/index-map_09.jpg\" width=\"159\" height=\"29\" onClick=\"maplayer()\" style=\"cursor:hand\" alt=\"图层控制\"></td>\r\n  </tr>\r\n    <tr>\r\n    <td><img src=\"images/index-map_10.jpg\" width=\"159\" height=\"29\" onClick=\"mapinfo()\" style=\"cursor:hand\" alt=\"点信息\"></td>\r\n  </tr>\r\n    <tr>\r\n    <td><img src=\"images/cal_dist.JPG\" width=\"159\" height=\"29\" onClick=\"cal_dist()\" style=\"cursor:hand\" alt=\"测距\"></td>\r\n  </tr>\r\n  \r\n</table>\r\n<div id=\"layer1\" style=\"position:absolute; left:12px; top:366px; width:100px; height:18px; z-index:2;font-size:12px;color:Red;\">当前状态：</div>\r\n<div id=\"center&zoom\" style=\"position:absolute; left:8px; top:390px; width:577px; height:33px; z-index:3\"> \r\n  <!--显示中心点和zoom值-->\r\n  <table width=\"526\" border=\"0\">\r\n    <tr>\r\n      <td width=\"250\"> <font size=\"2\">中心点(度)Ｘ:</font> \r\n        <input type=\"Text\" style=\"border:none;background:#DFFFDF;text-align:left;\" name=\"oldx\">\r\n");
      out.write("      </td>\r\n      <td width=\"266\"> <font size=\"2\">Ｙ:</font> \r\n        <input type=\"Text\" style=\"border:none;background:#DFFFDF;text-align:left;\" name=\"oldy\">\r\n  \t  </td>\r\n    </tr>\r\n    <tr>\r\n      <td width=\"250\"> <font size=\"2\">视野(km):</font> \r\n        <input type=\"Text\" style=\"border:none;background:#DFFFDF;text-align:left;\" name=\"oldzoom\">\r\n      </td>\r\n      <td width=\"266\"><font size=\"2\">距离(m):</font> \r\n        <input type=\"Text\" style=\"border:none;background:#DFFFDF;text-align:left;\" name=\"distance\"></td>\r\n    </tr>\r\n  </table>  \r\n</div>\r\n</body>\r\n<script language=\"JavaScript\" src=\"scripts/init.js\">\r\n</script>\r\n<script language=\"JavaScript\">\r\nfunction maplayer(){\r\n\t//document.all.mxx.style.display=\"\";\r\n\tvar layer//打开图层控制页面\r\n\tlayer=window.open(\"layer.jsp\")\r\n\t\r\n}\r\n</script>\r\n</html>\r\n");
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}

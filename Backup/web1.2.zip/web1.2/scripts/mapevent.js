function mapmousedown(){
	if(window.event.srcElement.id=="imgmap"){
		if (state=="big"){
			document.all.seltable.style.display=""
			document.all.seltable.style.width=0
		 	document.all.seltable.style.height=0
			document.all.seltable.style.left=window.event.clientX
			document.all.seltable.style.top=window.event.clientY
			oldx=window.event.clientX
			oldy=window.event.clientY
			eventstate="eventbegin"
		}
		if(state=="small"){
			document.all.selimg.style.display=""
			document.all.selimg.style.left=window.event.clientX
			document.all.selimg.style.top=window.event.clientY
			eventstate="eventbegin"
		}
		if(state=="info"){
			document.all.selimg.style.display=""
			document.all.selimg.style.left=window.event.clientX
			document.all.selimg.style.top=window.event.clientY
			eventstate="eventbegin"
		}
		if(state=="pan"){
			oldx=window.event.clientX
			oldy=window.event.clientY
			startx=parseInt(document.all.imgmap.style.left)
			starty=parseInt(document.all.imgmap.style.top)
			eventstate="eventbegin"
		}
	}
	window.event.returnValue=false
}
function mapmousemove(){
	if(window.event.srcElement.id=="imgmap"){
		if(state=="big"){
			if(window.event.button==1){
				box()
			}
		}
		if(state=="pan"){
			if(window.event.button==1){
				pan()
			}
		}
		
	}
	window.event.returnValue=false
}

function mapmouseup(){
	if(eventstate=="eventbegin"){
		if(state=="big"){
			document.all.seltable.style.display="none"
			document.all.selimg.style.display="none"
			mapbigger()
		}
		if(state=="small"){
			document.all.selimg.style.display="none"
			mapsmaller()
		}
		if(state=="pan"){
			document.all.selimg.style.display="none"
			mappaner()
		}
		if(state=="info"){
			//document.all.selimg.style.display="none"
			mapinfoer();
			
		}
		
		eventstate="eventend"
		
	}
	window.event.returnValue=false
}

function tablemove(){
	var width
	var height
	if(window.event.button==1){
		width=window.event.clientX-oldx
		height=window.event.clientY-oldy
		if(width<0&&height<0){
			document.all.seltable.style.left=window.event.clientX
			document.all.seltable.style.top=window.event.clientY
		}
		else if(width<0){
			document.all.seltable.style.left=window.event.clientX
	    }
		else if(height<0){
			document.all.seltable.style.top=window.event.clientY
		}
		document.all.seltable.style.height=Math.abs(height)+1
		document.all.seltable.style.width=Math.abs(width)+1
	}
	window.event.returnValue=false
}

function mapbig(){
	resetimg()
	state="big"
	document.all.imgmap.style.cursor="default"
	document.all.bigimg.src="images/index-map-a_03.jpg"
	document.all.layer1.innerText="��ǰ״̬:�Ŵ�"
}

function mapsmall(){
	resetimg()
	state="small"
	document.all.imgmap.style.cursor="default"
	document.all.smallimg.src="images/index-map-a_05.jpg"
	document.all.layer1.innerText="��ǰ״̬:��С"
}

function mappan(){
	resetimg()
	state="pan"
	document.all.imgmap.style.cursor="move"
	document.all.panimg.src="images/index-map-a_06.jpg"
	document.all.layer1.innerText="��ǰ״̬:����"
}
function mapinfo(){
	resetimg()
	state="info"
	document.all.imgmap.style.cursor="default"
	//document.all.panimg.src="images/index-map-a_06.jpg"
	document.all.layer1.innerText="��ǰ״̬:����Ϣ"
}
function cal_dist(){
	resetimg()
	state="cal_dist"	
	document.all.imgmap.style.cursor="crosshair"	
	document.all.layer1.innerText="��ǰ״̬:���"
	//================================================================
	document.all.mapCanvas.style.display="";
	document.all.mxx.style.display="";
	//var jg = new jsGraphics("mapCanvas");
	//var jg2 = new jsGraphics("mxx");
	jg.clear();
   	jg2.clear();
   jg.setColor("#ff0000"); // red
   jg2.setColor("#ff0000"); 
   jg.setStroke(2); 
   jg2.setStroke(2); 
     
  	var Is_Draw = true;
	var line_num=0;
	var mainMap_x;
	var mainMap_y;
	var map_zoom=document.all.oldzoom.value;
	var map_dist=0;
	var dBuffer;
	var msIsDown=false;
	

	mapCanvas.onmouseup =  function() {
		if(Is_Draw){
			mainMap_x = event.x-9;
			mainMap_y = event.y-24 ;
			msIsDown = true;
			}

	}

	mapCanvas.onmousemove = function() {
		if (msIsDown){

			var currentX = event.x-9 ;
			var currentY = event.y-24 ;

			jg.clear();
			
			jg.drawLine(mainMap_x, mainMap_y, currentX,currentY);
			jg.paint();
									

		}
	}

	mapCanvas.onmousedown = function() {
		if(Is_Draw){			
			
			if(line_num>0){
			
				var currentX = event.x-9 ;
				var currentY = event.y-24 ;
				jg2.drawLine(mainMap_x, mainMap_y, currentX,currentY);
				jg2.paint();
				dBuffer=(currentX-mainMap_x)*(currentX-mainMap_x)+(currentY-mainMap_y)*(currentY-mainMap_y);
				dBuffer=Math.sqrt(dBuffer);
				dBuffer=dBuffer*map_zoom*2.092;//���Ա���ϵ��
				map_dist=map_dist+dBuffer;
				document.all.distance.value=map_dist;
				
			
			}		
				
				line_num++;
			
			msIsDown = false;//����갴�±�־λ��0
			}
		//clearDrawingCanvas(lineTool);//�����lineTool(drawCanvas)�ϵľ���
	}
	mapCanvas.ondblclick=function(){	
		Is_Draw=false;
		msIsDown = false;//����갴�±�־λ��0	
	
	
	}
	//=================================================================
	
}

function downloadstate(){
	var dlstate=document.all.imgmap.readyState
	if(dlstate=="uninitialized"){
		document.all.downloadimg.style.display=""
		document.all.imgmap.style.visibility="hidden"
	}
	if(dlstate=="loading"){
		document.all.downloadimg.style.display=""
		document.all.imgmap.style.visibility="hidden"
		if(document.all.mapboundframe.style.display==""){
			mapbounder()
		}
		setlocation()
	}
	if(dlstate=="complete"){
		document.all.imgmap.style.pixelLeft=0;   
    	        document.all.imgmap.style.pixelTop=0;
		document.all.downloadimg.style.display="none"
		document.all.imgmap.style.visibility="visible"
	}
}

function bounddownloadstate(){
	var dlstate=document.all.boundmap.readyState
	if(dlstate=="uninitialized"){
		document.all.downloadimg.style.display=""
		document.all.boundmap.style.visibility="hidden"
	}
	if(dlstate=="loading"){
		document.all.downloadimg.style.display=""
		document.all.boundmap.style.visibility="hidden"
	}
	if(dlstate=="complete"){
		document.all.downloadimg.style.display="none"
		document.all.boundmap.style.visibility="visible"
	}
}

  function mapreset(){
    buttonreset();
    rquchange("rqutype=mapreset&"+Math.random());
    document.all.layer1.innerText="��ǰ״̬:ȫͼ";
    state="";
  }
  
  
  function rquchange(newrqu){
    document.all.imgmap.src=servleturl+"?"+newrqu;
  }
  
  <!--�Ŵ��������-->
  function mapbigger(){
    var centerx;
    var centery;
    var left=parseInt(document.all.imgmap.style.left);
    var top=parseInt(document.all.imgmap.style.top);
    centerx=oldx-left;
    centery=oldy-top;

    newzoom=0.5;
    rquchange("rqutype=mapchange&centerx="+centerx+"&centery="+centery+"&newzoom="+newzoom);
    if(document.all.boundmap.style.diplay==""){
    	   mapbound();
    }
  }  
  

  <!--���β�������-->
  function mappanner(){
    if(newx-oldx!=0 && newy-oldy!=0){
       	var centerx;
       	var centery;
       	var oldcenterx=parseInt(document.all.imgmap.width)/2;
       	var oldcentery=parseInt(document.all.imgmap.height)/2;
    	centerx=oldcenterx+(oldx-newx);
    	centery=oldcenterx+(oldy-newy);
    	newzoom=1;
    	rquchange("rqutype=mapchange&centerx="+centerx+"&centery="+centery+"&newzoom="+newzoom);
    	if(document.all.boundmap.style.diplay==""){
    	   mapbound();
    	}
    	//��ͼͼƬ���ù�λ
    	
    }
  }
  
  <!--��С��������-->
  function mapsmaller(){
    var centerx;
    var centery;
    var left=parseInt(document.all.imgmap.style.left);
    var top=parseInt(document.all.imgmap.style.top);
    centerx=oldx-left;
    centery=oldy-top;
    newzoom=1.5;
    rquchange("rqutype=mapchange&centerx="+centerx+"&centery="+centery+"&newzoom="+newzoom);
    if(document.all.boundmap.style.diplay==""){
    	   mapbound();
    }
  }  

  <!--ӥ����Ӧ����-->
  function mapbounder(){
    document.all.boundmap.src=servleturl+"?rqutype=boundmap&"+Math.random();
    //alert("success");
  }
function mapbigger(){
	var centerx
	var centery
	var newzoom
	var frametop
	var frameleft
	var tablewidth
	var tablehigh
	var picwidth
	var pichigh
	frametop=parseInt(document.all.mapframe.style.top)
	frameleft=parseInt(document.all.mapframe.style.left)
	tablehigh=parseInt(document.all.seltable.style.height)
	tablewidth=parseInt(document.all.seltable.style.width)
	tableleft=parseInt(document.all.seltable.style.left)
	tabletop=parseInt(document.all.seltable.style.top)
	picwidth=parseInt(document.all.imgmap.style.width)
	pichigh=parseInt(document.all.imgmap.style.height)
	centerx=tablewidth/2+tableleft-frameleft
	centery=tablehigh/2+tabletop-frametop
	if(tablewidth>tablehigh){
		newzoom=tablewidth/picwidth
	}
	else{
		newzoom=tablehigh/pichigh
	}
	if(newzoom==0){
		newzoom=0.5
	}
	chgmapsrc("rqutype=mapchange&centerx="+centerx+"&centery="+centery+"&newzoom="+newzoom)
}

function mapsmaller(){
	var centerx
	var centery
	var frametop
	var frameleft
	frametop=parseInt(document.all.mapframe.style.top)
	frameleft=parseInt(document.all.mapframe.style.left)
	centerx=window.event.clientX-(frameleft+1)
	centery=window.event.clientY-(frametop+1)
	newzoom=1.5;
	chgmapsrc("rqutype=mapchange&centerx="+centerx+"&centery="+centery+"&newzoom="+newzoom)
}

function mappaner(){
	var centerx
	var centery
	var picwidth
	var pichigh
	var picleft
	var pictop
	picwidth=parseInt(document.all.imgmap.style.width)
	pichigh=parseInt(document.all.imgmap.style.height)
	pictop=parseInt(document.all.imgmap.style.top)
	picleft=parseInt(document.all.imgmap.style.left)
	if(pictop!=0&&picleft!=0){
		centerx=picwidth/2-picleft
		centery=pichigh/2-pictop
		newzoom=1
		chgmapsrc("rqutype=mapchange&centerx="+centerx+"&centery="+centery+"&newzoom="+newzoom)
		document.all.imgmap.style.left=0
		document.all.imgmap.style.top=0
	}
}

function mapsmallpaner(){
	var centerx
	var centery
	var frametop
	var frameleft
	var boundhigh
	var maphigh
	frametop=parseInt(document.all.mapboundframe.style.top)
	frameleft=parseInt(document.all.mapboundframe.style.left)
	centerx=window.event.clientX-(frameleft+1)
	centery=window.event.clientY-(frametop+1)
	
	chgmapsrc("rqutype=smallpanmap&centerx="+centerx+"&centery="+centery)
}

function mapreset(){
	chgmapsrc("rqutype=mapreset&"+Math.random())
	document.all.layer1.innerText="��ǰ״̬:ȫͼ";
}

function mapbound(){
	if(document.all.mapboundframe.style.display=="none"){
		mapbounder()
		document.all.mapboundframe.style.display=""
	}
	else{
		document.all.mapboundframe.style.display="none"
	}
}

function mapbounder(){
	//document.all.boundmap.src=mapboundserviceurl
	//document.all.boundmap.src=mapboundserviceurl+Math.random();
	document.all.boundmap.src=mapserviceurl+"?rqutype=boundmap&"+Math.random();//ÿ����һ�ξͱ�֤ˢ��һ�Σ�
}

function chgmapsrc(querystring){
	var locationrul
	locatinourl="&oldx="+document.all.oldx.value+"&oldy="+document.all.oldy.value+"&oldzoom="+document.all.oldzoom.value
	document.all.imgmap.src=mapserviceurl+"?"+querystring+locatinourl
}

function setlocation(){	
	center.document.location.reload()
	zoom.document.location.reload()
}
